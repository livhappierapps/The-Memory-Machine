import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  userId: text("user_id").primaryKey(),
  apiKey: text("api_key"),
  defaultModel: text("default_model").notNull().default("grok-3"),
  maxContextMessages: integer("max_context_messages").notNull().default(100),
  mcpToken: text("mcp_token"),
  mcpTokenHash: text("mcp_token_hash"),
  paymentStatus: text("payment_status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
